-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10c101.p.ssafy.io    Database: throwng
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `quiz_id` bigint NOT NULL AUTO_INCREMENT,
  `answer` varchar(100) NOT NULL,
  `choice` json DEFAULT NULL,
  `preview_url` varchar(200) DEFAULT NULL,
  `question` varchar(500) NOT NULL,
  `quiz_image` varchar(200) DEFAULT NULL,
  `quiz_type` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (1,'X',NULL,NULL,'걸그룹 에스파의 데뷔곡은 Next Level이다.',NULL,'OX'),(2,'3','{\"1\": \"20\", \"2\": \"22\", \"3\": \"23\", \"4\": \"24 : How to find true love and happiness \"}',NULL,'혁오의 ‘Tomboy’, ‘Die alone’, ‘Paul’ 등이 속한 앨범은?',NULL,'MULTIPLE'),(3,'Attention',NULL,NULL,'다음 노래는 우리나라 노래의 영어 가사를 한글로 바꾼 것이다. 이 노래의 제목은? (영어) \r \'질문은 그만\r 질문은 그만\r 관심을 원해\r 관심을 원해\r 너를 보면 조마조마하고 긴장돼\'',NULL,'SUBJECTIVE'),(4,'4','{\"1\": \"고백\", \"2\": \"참고 살아\", \"3\": \"왜 벌써 가\", \"4\": \"3호선 매봉역\"}',NULL,'다음 중 다이나믹 듀오의 노래가 아닌 것은 ?',NULL,'MULTIPLE'),(5,'3','{\"1\": \"One and Only\", \"2\": \"Get A Guitar\", \"3\": \"첫 만남은 계획대로 되지 않아\", \"4\": \"특\"}',NULL,'다음 중 발매 날짜가 가장 빠른 노래는?',NULL,'MULTIPLE'),(6,'2','{\"1\": \"마크\", \"2\": \"도영\", \"3\": \"제노\", \"4\": \"해찬\"}',NULL,'NCT DREAM의 멤버가 아닌 사람은?',NULL,'MULTIPLE'),(7,'LOVE DIVE',NULL,NULL,'이 안무가 들어가는 노래 제목은? (영어)','https://throwng.s3.ap-northeast-2.amazonaws.com/movingwonyeong.gif','SUBJECTIVE'),(8,'민규',NULL,NULL,'그룹 세븐틴 사진입니다. [A]에 들어갈 인물의 이름은?','https://throwng.s3.ap-northeast-2.amazonaws.com/seventeen.png','SUBJECTIVE'),(9,'갈피',NULL,NULL,'\'그러다 밤이 찾아오면 우리 둘만의 비밀을 새겨요\n 추억할 그 밤 위에 OO 를 꽂고선 남 몰래 펼쳐보아요\'\n 빈칸에 들어갈 말은?',NULL,'SUBJECTIVE'),(10,'O',NULL,NULL,'BTS는 UNICEF의 글로벌 기부 캠페인의 일환으로 \'러브 마이셀프\' 캠페인을 진행했다.',NULL,'OX'),(11,'2','{\"1\": \"태양의후예\", \"2\": \"별에서 온 그대\", \"3\": \"주군의 태양\", \"4\": \"구르미 그린 달빛\"}',NULL,'가수 거미가 OST 에 참여하지 않은 드라마는?',NULL,'MULTIPLE'),(12,'Boys And Girls',NULL,'https://p.scdn.co/mp3-preview/7e234287c14779fac04d81758297b1029617e112?cid=cb686ac392d244b5a9acddf75f9c9801','이 노래의 제목은? (영어)','','SUBJECTIVE'),(13,'5',NULL,NULL,'다비치 이해리와 강민경의 나이 차이는 몇살일까요? (숫자)',NULL,'SUBJECTIVE'),(14,'2','{\"1\": \"Black\", \"2\": \"SPOT!\", \"3\": \"그 XX\", \"4\": \"Good Boy\"}',NULL,'지드래곤의 노래가 아닌 것은?',NULL,'MULTIPLE'),(15,'저녁 하늘',NULL,NULL,'초성 “ㅈㄴ ㅎㄴ“ 에 해당하는 노래 제목을 맞춰보세요',NULL,'SUBJECTIVE'),(16,'21',NULL,NULL,'에스파 + 아이브 + 르세라핌 + 엔믹스 멤버 수를 다 합치면 몇 명 일까요? (숫자)',NULL,'SUBJECTIVE'),(17,'피카부',NULL,'https://p.scdn.co/mp3-preview/2cf3de77dcf406efbc29787e03e339416856daf9?cid=cb686ac392d244b5a9acddf75f9c9801','이 노래의 제목은? (한글)',NULL,'SUBJECTIVE'),(18,'X',NULL,NULL,'BTS는 2021년 Butter로 빌보드 핫 100에서 12주 연속 1위를 기록했다.',NULL,'OX'),(19,'3','{\"1\": \"겨울연가\", \"2\": \"대장금\", \"3\": \"피아노\", \"4\": \"내 이름은 김삼순\"}','https://p.scdn.co/mp3-preview/ae9540bb8991f8fd4fb47ae48cb57761f70bb646?cid=cb686ac392d244b5a9acddf75f9c9801','이 노래는 어떤 드라마의 OST로 사용되었나요?',NULL,'MULTIPLE'),(20,'X',NULL,NULL,'카더가든의 Home Sweet Home 은 정규 앨범 APARTMENT의 타이틀 곡이다.',NULL,'OX'),(21,'3','{\"1\": \"육군\", \"2\": \"해군\", \"3\": \"카투사\", \"4\": \"해병대\"}',NULL,'밴드 그룹 데이식스(DAY6)에 보컬과 랩, 그리고 베이스의 포지션을 가진 영케이의 군 복무 부대는?',NULL,'MULTIPLE'),(22,'3','{\"1\": \"존박\", \"2\": \"허각\", \"3\": \"최승희\", \"4\": \"김그림\"}',NULL,'슈퍼스타K 시즌2 에서 일명 \'조별과제 멸망편, 쳐밀도\' 로 유명한 \'죽어도 못 보내\' 무대에 오르지 않았던 사람은?',NULL,'MULTIPLE'),(23,'Fake Love',NULL,NULL,'다음 노래는 우리나라 노래의 영어 가사를 한글로 바꾼 것이다. 이 노래의 제목은? (영어)\r \'난 정말 지겨워 이 거짓사랑 거짓사랑 거짓사랑\r 정말 미안한데 이것 거짓사랑 거짓사랑 거짓사랑\'',NULL,'SUBJECTIVE'),(24,'2','{\"1\": \"La La Land\", \"2\": \"Begin Again\", \"3\": \"About Time\", \"4\": \"Mamma mia\"}',NULL,'Adam Levine(Maroon 5)가 부른 Lost Stars는 어떤 영화의 OST일까요?',NULL,'MULTIPLE'),(25,'X',NULL,NULL,'아이브의 데뷔곡 ELEVEN 은 당시 음악 방송 12관왕을 했다.',NULL,'OX'),(26,'헤어지지 못하는 여자 떠나가지 못하는 남자',NULL,NULL,'초성 ‘ㅎㅇㅈㅈ ㅁㅎㄴ ㅇㅈ ㄸㄴㄱㅈ ㅁㅎㄴ ㄴㅈ’ 에 해당하는 노래 제목을 맞춰보세요.',NULL,'SUBJECTIVE');
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:11:20
