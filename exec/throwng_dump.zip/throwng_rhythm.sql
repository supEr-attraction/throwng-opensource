-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10c101.p.ssafy.io    Database: throwng
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rhythm`
--

DROP TABLE IF EXISTS `rhythm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rhythm` (
  `rhythm_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(400) NOT NULL,
  `preview_url` varchar(200) NOT NULL,
  `artist_id` int NOT NULL,
  PRIMARY KEY (`rhythm_id`),
  KEY `FK_artist_TO_rhythm_1` (`artist_id`),
  CONSTRAINT `FK_artist_TO_rhythm_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rhythm`
--

LOCK TABLES `rhythm` WRITE;
/*!40000 ALTER TABLE `rhythm` DISABLE KEYS */;
INSERT INTO `rhythm` VALUES (1,'Hype Boy','https://p.scdn.co/mp3-preview/7c55950057fc446dc2ce59671dff4fa6b3ef52a7?cid=cb686ac392d244b5a9acddf75f9c9801',5),(2,'ETA','https://p.scdn.co/mp3-preview/e076cd31805e449dae7d991711df5f2ff920b375?cid=cb686ac392d244b5a9acddf75f9c9801',5),(3,'Super Shy','https://p.scdn.co/mp3-preview/dab062e2cc708a2680ce84953a3581c5a679a230?cid=cb686ac392d244b5a9acddf75f9c9801',5),(4,'Hurt','https://p.scdn.co/mp3-preview/6df87f1a4b207f284916aa305f20a9eac0a88f75?cid=cb686ac392d244b5a9acddf75f9c9801',5),(5,'Blueming','https://p.scdn.co/mp3-preview/12ba2a0451726e0a4fe53d71c300db7ed728b8f1?cid=cb686ac392d244b5a9acddf75f9c9801',56),(6,'Holssi','https://p.scdn.co/mp3-preview/8e4d5adab556f1f7fa916b8404a8f1cc27e3a371?cid=cb686ac392d244b5a9acddf75f9c9801',56),(7,'I stan U','https://p.scdn.co/mp3-preview/eed1b48a2dc49f3c0de62eb8640d232f2662c55b?cid=cb686ac392d244b5a9acddf75f9c9801',56),(8,'Celebrity','https://p.scdn.co/mp3-preview/ab879698733f3b9ff65a70a4be0b60b92b94bb59?cid=cb686ac392d244b5a9acddf75f9c9801',56),(9,'Spicy','https://p.scdn.co/mp3-preview/d28e64d4864b1cf99e0e01738b32e3f95a8ce1c4?cid=cb686ac392d244b5a9acddf75f9c9801',14),(10,'Illusion','https://p.scdn.co/mp3-preview/e231722c5e5c751091f8dff8a96c59719ab8fcb2?cid=cb686ac392d244b5a9acddf75f9c9801',14),(11,'Black Mamba','https://p.scdn.co/mp3-preview/3c6ed1a71d2684e69168eacf27cab31880f30d8f?cid=cb686ac392d244b5a9acddf75f9c9801',14),(12,'Girls','https://p.scdn.co/mp3-preview/a3d57978f4a877124d87238ed9b5217f45cd95c5?cid=cb686ac392d244b5a9acddf75f9c9801',14),(13,'Radio','https://p.scdn.co/mp3-preview/e20b9bf28b5d7c6c795d45e66e8fbe4d81e1c220?cid=cb686ac392d244b5a9acddf75f9c9801',24),(14,'Aqua Man','https://p.scdn.co/mp3-preview/9877b33e7eab1c7c23f3c5814d829f53eb5407ca?cid=cb686ac392d244b5a9acddf75f9c9801',24),(15,'Boogie On & On','https://p.scdn.co/mp3-preview/acf9da21c08daf140d5501cd6b42f8f4723dcab1?cid=cb686ac392d244b5a9acddf75f9c9801',24),(16,'Vibra','https://p.scdn.co/mp3-preview/beccdfb1c7eae9550f769d211d7fdfd472eadc8e?cid=cb686ac392d244b5a9acddf75f9c9801',24),(17,'Wi Ing Wi Ing','https://p.scdn.co/mp3-preview/70ce8fe4dee0477d026a907270373957f99539d4?cid=cb686ac392d244b5a9acddf75f9c9801',40),(18,'Comes and Goes','https://p.scdn.co/mp3-preview/452120c1143e818e085a9b5fa9c9b18974624dbd?cid=cb686ac392d244b5a9acddf75f9c9801',40),(19,'PARACHUTE','https://p.scdn.co/mp3-preview/e83ab7fce4bf75fe123c8da24bd5885cbfc4e1f5?cid=cb686ac392d244b5a9acddf75f9c9801',40),(20,'Bawling','https://p.scdn.co/mp3-preview/6a77e859c3d638c0a83db6f7a050fe22cdf3d9fa?cid=cb686ac392d244b5a9acddf75f9c9801',40),(21,'해야','https://p.scdn.co/mp3-preview/4517b2dae7d091d7c9dee0bf712eaa95d17f8707?cid=cb686ac392d244b5a9acddf75f9c9801',23),(22,'Baddie','https://p.scdn.co/mp3-preview/c907a81d1f1763c373f2b0f124307a93d0c3dd08?cid=cb686ac392d244b5a9acddf75f9c9801',23),(23,'Kitsch','https://p.scdn.co/mp3-preview/8ab8fa8f285978fed46563d55397f567516bba5e?cid=cb686ac392d244b5a9acddf75f9c9801',23),(24,'Either Way','https://p.scdn.co/mp3-preview/f44ca2269e3f5222244b71a3f240459acc3186bd?cid=cb686ac392d244b5a9acddf75f9c9801',23);
/*!40000 ALTER TABLE `rhythm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:11:18
