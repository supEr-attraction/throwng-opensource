-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10c101.p.ssafy.io    Database: throwng
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist` (
  `artist_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`artist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=419 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (1,'ZICO'),(2,'Jukjae'),(3,'Kwon Jin Ah'),(4,'Leessang'),(5,'NewJeans'),(6,'Jazzyfact'),(7,'DELISPICE'),(8,'G-DRAGON'),(9,'Yerin Baek'),(10,'Gist'),(11,'Daniel Caesar'),(12,'Jay Park'),(13,'Troye Sivan'),(14,'aespa'),(15,'Sun Rai'),(16,'LE SSERAFIM'),(17,'HONNE'),(18,'LEE SEUNG HWAN'),(19,'Lauv'),(20,'V'),(21,'Crush'),(22,'JANNABI'),(23,'IVE'),(24,'Beenzino'),(25,'Silica Gel'),(26,'Loveholic'),(27,'We Are The Night'),(28,'The Black Skirts'),(29,'Lyn'),(30,'wave to earth'),(31,'D.O.'),(32,'MONSTA X'),(33,'KISS OF LIFE'),(35,'Car, the garden'),(36,'Block B'),(37,'Eminem'),(38,'ESEGYE'),(39,'Park Hyo Shin'),(40,'HYUKOH'),(41,'NCT 127'),(42,'Woogotsa'),(43,'박명수'),(44,'GIRIBOY'),(45,'Leellamarz'),(46,'NMIXX'),(47,'iKON'),(48,'Paul Blanco'),(49,'Taylor Swift'),(50,'SHINee'),(51,'Sung Si Kyung'),(52,'Gist'),(53,'LUCY'),(54,'DAY6'),(55,'Red Velvet'),(56,'IU'),(57,'MrUnknownPotato'),(58,'BIBI'),(59,'Suzy'),(60,'크라잉넛'),(61,'TWICE'),(62,'Slvmbrs'),(63,'QWER'),(64,'IZ*ONE'),(65,'Glenn Stafford'),(66,'Pinkfong'),(67,'BE\'O'),(68,'Norazo'),(69,'Song Chang Sik'),(70,'PSY'),(71,'Kim Ji Soo'),(72,'BSS'),(73,'Epik High'),(74,'Paul Kim'),(75,'YB'),(76,'Ha Hyun Woo'),(77,'Nucksal'),(78,'Six Bomb'),(79,'Mukimukimanmansu'),(80,'XENO'),(81,'Bada'),(82,'UmYull'),(83,'SEVENTEEN'),(84,'셀바이뮤직 Sellbuymusic'),(85,'King Gnu'),(86,'Clean Bandit'),(87,'Woo'),(88,'SUNMI'),(89,'방대식'),(90,'ILLIT'),(91,'COOL'),(92,'Alan Walker'),(93,'(G)I-DLE'),(94,'BABYMONSTER'),(95,'어그먼트'),(96,'Kids Pop'),(97,'BTS'),(98,'Lee Juck'),(99,'TAEYANG'),(100,'MeloMance'),(101,'Colde'),(102,'THAMA'),(103,'OVAN'),(104,'Lil Moshpit'),(105,'JENNIE'),(106,'BIGBANG'),(107,'AKMU'),(108,'One More Chance'),(109,'Jason Derulo'),(110,'Girls\' Generation'),(111,'AOA'),(112,'2NE1'),(113,'2PM'),(114,'CHUNG HA'),(115,'Lee Hyori'),(116,'Kesha'),(117,'Hoàng Thùy Linh'),(118,'Jessi'),(119,'HWASA'),(120,'miss A'),(121,'Airman'),(122,'HAAN'),(123,'Wonstein'),(124,'Tyler, The Creator'),(125,'Kendrick Lamar'),(126,'CRYING NUT'),(127,'O3ohn'),(128,'OH MY GIRL'),(129,'fromis_9'),(130,'Zac Efron'),(131,'DAVICHI'),(132,'Sandeul'),(133,'CHANGMO'),(134,'Ariana Grande'),(135,'Secret'),(136,'N.Flying'),(137,'KARA'),(138,'Khalid'),(139,'Young K'),(140,'Kim Hyunshik'),(141,'CASIOPEA'),(142,'Stray Kids'),(143,'PATEKO'),(144,'BIG Naughty'),(145,'PARK HYEON JIN'),(146,'Frankie Valli'),(147,'CAN'),(148,'hanali'),(149,'Choi Yu Ree'),(150,'DAY6 (Even of Day)'),(151,'NCT WISH'),(152,'graves'),(153,'Maroon 5'),(154,'Younha'),(155,'Charlie Puth'),(156,'Lim Changjung'),(157,'BLACKPINK'),(158,'EXO'),(159,'Dynamicduo'),(160,'Vaundy'),(161,'SISTAR'),(162,'국제 오케스트라'),(163,'Sunwoojunga'),(164,'Imrubin'),(165,'Rosemotel'),(166,'seeso'),(167,'ASH ISLAND'),(168,'TOMTOMI'),(169,'HOMIES'),(170,'Park Jiyeon'),(171,'엘피레코드'),(172,'황성민'),(173,'Beom Su Park'),(174,'Zion.T'),(175,'남진'),(176,'김범수'),(177,'Park Hyun-Bin'),(178,'Linkin Park'),(179,'Various Artists'),(180,'Sanullim'),(181,'엘키즈 동요'),(182,'Kanye West'),(183,'Frank Ocean'),(184,'Bernard Herrmann'),(185,'Fujii Kaze'),(186,'TOUCHED'),(187,'LANY'),(188,'Kenshi Yonezu'),(189,'CRUCiAL STAR'),(190,'Wings of the ISANG'),(191,'Wonder Girls'),(192,'TAEYONG'),(193,'Yu Seung Woo'),(194,'Grizzly'),(195,'Auli\'i Cravalho'),(196,'SORAN'),(197,'HYUN SEO'),(198,'Billie Eilish'),(199,'Kim Hyung Joong'),(200,'Tones And I'),(201,'The Weeknd'),(202,'LeeHi'),(203,'Supreme Team'),(204,'TWS'),(205,'TAEYEON'),(206,'여행스케치'),(207,'f(x)'),(208,'San E'),(209,'Hareem'),(210,'Lim Jae Beum'),(211,'Sodam'),(212,'Wetter'),(213,'Dasutt'),(214,'HYOLYN'),(215,'Jang Beom June'),(216,'John Park'),(217,'TVXQ!'),(218,'Turtles'),(219,'LA POEM'),(220,'jisokuryClub'),(221,'T-ARA'),(222,'TULA'),(223,'J.min'),(224,'Armadillo'),(225,'Kim Kwang Seok'),(226,'MINO'),(227,'데이먼스 이어 Damons year'),(228,'KOREA CRACKER'),(229,'FIFTY FIFTY'),(230,'GD&TOP'),(231,'Maronie Friends'),(232,'KIRIN'),(233,'So Soo Bin'),(234,'SKULL'),(235,'SRB Project'),(236,'Urban Zakapa'),(237,'BUZZ'),(238,'Bobby Kim'),(240,'SOLE'),(241,'Loco'),(242,'Jeon Juhyeon'),(243,'10CM'),(244,'Agust D'),(245,'SE SO NEON'),(246,'JUPITER'),(247,'Sugarbowl'),(248,'ALEPH'),(249,'GOT7'),(250,'HyunA'),(251,'Pink Sweat$'),(252,'Fitz and The Tantrums'),(253,'Guns N\' Roses'),(254,'BOL4'),(255,'UEFA'),(256,'Sam Smith'),(257,'Justin Bieber'),(258,'MAMAMOO'),(259,'Homeboy'),(260,'HENRY'),(261,'Simon Dominic'),(262,'GyeongseoYeji'),(263,'Dept'),(264,'amin'),(265,'Busker Busker'),(266,'WINNER'),(267,'Kang min jeong'),(268,'HAEUN'),(269,'Woody'),(270,'Rap La Rue'),(271,'j-hope'),(272,'Izi'),(273,'Post Malone'),(274,'Noel'),(275,'유태'),(276,'서이브'),(277,'HUS'),(278,'Herz Analog'),(279,'2AM'),(280,'BTOB'),(281,'Kiha & The Faces'),(282,'Night Off'),(283,'B1A4'),(284,'泰葉'),(285,'DEAN'),(286,'Kim Dong Ryul'),(287,'OWALLOIL'),(288,'TransFixion'),(289,'Yoo Jung Seok'),(290,'HYNN'),(291,'Lee Mujin'),(292,'J Rabbit'),(293,'PARKMOONCHI'),(294,'NAOKI'),(295,'HEIZE'),(296,'pH-1'),(297,'Glen Check'),(298,'IT’S'),(299,'ROZY'),(300,'Rick Astley'),(301,'전영호'),(302,'DIA'),(303,'Ahn Ye Eun'),(304,'SECHSKIES'),(305,'BROWN EYED SOUL'),(306,'bubble sound'),(307,'Primary'),(308,'Chance'),(309,'명카드라이브'),(310,'Oasis'),(311,'Good Neighbours'),(312,'H.E.R.'),(313,'One Direction'),(314,'Na Hoon-A'),(315,'ASHGRAY'),(316,'Electric Light Orchestra'),(317,'Jo Ju-Bong'),(318,'정선화'),(319,'Yung Bae'),(320,'Louis Dunford'),(321,'Liam Gallagher'),(322,'Green Day'),(323,'SS501'),(324,'ASMRZ'),(325,'Djo'),(326,'Naul'),(327,'Baby V.O.X'),(328,'cherryfilter'),(329,'FTISLAND'),(330,'Aimyon'),(331,'Yoon Jong Shin'),(332,'Gang Seong'),(333,'Lee Soo Young'),(334,'Novelbright'),(335,'So Chanwhee'),(336,'Don Toliver'),(337,'Beyoncé'),(338,'Nujabes'),(339,'Stella Jang'),(340,'JO YURI'),(341,'WENDY'),(342,'동요'),(343,'¥$'),(344,'Tabber'),(345,'Benson Boone'),(346,'Park So Eun'),(347,'Drake'),(348,'Kodak Black'),(349,'Mustard'),(350,'Chet Baker'),(351,'Ed Sheeran'),(352,'Band Nah'),(353,'HA DONG GYUN'),(354,'S.Papa'),(355,'youra'),(356,'NCT DREAM'),(357,'Bobby Caldwell'),(358,'2Pac'),(359,'Olivia Dean'),(360,'SeeYa'),(361,'Sam Ryder'),(362,'MUSHVENOM'),(363,'Ocean Floor Orchestra'),(364,'신장식'),(365,'Cheon'),(366,'코요태'),(367,'APRIL'),(368,'YUJU'),(376,'OKDAL'),(377,'LET ME KNOW'),(378,'siso'),(379,'Joe Sample'),(380,'ECLIPSE'),(381,'Billy Joel'),(382,'Standing Egg'),(383,'CODE KUNST'),(384,'Basixx'),(385,'Siine'),(386,'Nirvana'),(387,'The Quiett'),(388,'KEN KAMIKITA'),(389,'Becky Hill'),(390,'Nerd Connection'),(391,'Jack Johnson'),(392,'Mac Miller'),(393,'sakanaction'),(394,'SEKAI NO OWARI'),(395,'Playboi Carti'),(396,'Metro Boomin'),(397,'Destroy Lonely'),(398,'Lil Uzi Vert'),(399,'Anderson .Paak'),(400,'Ginger Root'),(401,'YUKIKA'),(402,'INFINITE'),(403,'T-Max'),(404,'B.A.P'),(405,'TEEN TOP'),(406,'Skule Toyama'),(407,'The 8-Bit Big Band'),(408,'4MEN'),(409,'tripleS'),(410,'Jung Kook'),(411,'MC MONG'),(412,'SPYAIR'),(413,'Lovelyz'),(414,'H1-KEY'),(415,'JOY'),(416,'DPR LIVE'),(417,'Iron'),(418,'Mrs. GREEN APPLE');
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:11:23
